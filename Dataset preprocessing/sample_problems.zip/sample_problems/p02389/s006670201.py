tate,yoko = map(int,input().split())


menseki = tate * yoko
syuu = 2*tate + yoko*2


print(menseki, syuu)
