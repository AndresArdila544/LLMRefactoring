import sys

a = int(sys.stdin.readline())
print(a**3)

