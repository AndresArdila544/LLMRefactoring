x = raw_input().split()
m = map(int,x)

m.sort()
a = m[0]
b = m[1]
c = m[2]

print a,b,c