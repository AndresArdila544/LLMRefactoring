a, b, c= map(int, input().split())
if a < b < c:
    re = 'Yes'
else:
    re = 'No'

print(re)
