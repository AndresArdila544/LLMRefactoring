import time
a = int(input())
print(time.strftime('%H:%M:%S', time.gmtime(a)))