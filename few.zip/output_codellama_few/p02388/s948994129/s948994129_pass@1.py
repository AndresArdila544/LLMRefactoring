import sys
print(int(sys.stdin.readline())**3)