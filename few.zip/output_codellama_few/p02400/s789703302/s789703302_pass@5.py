import sys
from math import pi

r = float(input())
print("%.10f %.10f" % (pi * r ** 2, 2 * pi * r))