```
num_list=input().split()
if int(num_list[0])<int(num_list[1])<int(num_list[2]):
    print('Yes')
else:
    print('No')
```