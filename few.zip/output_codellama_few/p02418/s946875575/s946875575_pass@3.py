s = str(input()) + s
if p in s:
    print("Yes")
else:
    print("No")