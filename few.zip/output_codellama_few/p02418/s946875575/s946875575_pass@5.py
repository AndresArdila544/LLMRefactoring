s=input()
p=input()
if p in s*2:print("Yes")else:print("No")