import sys

n = [int(x) for x in input().split()]
print(min(n), max(n), sum(n))