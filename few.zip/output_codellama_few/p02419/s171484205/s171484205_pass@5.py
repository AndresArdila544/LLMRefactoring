import sys
input = sys.stdin.read().lower()
print(input.count(input))