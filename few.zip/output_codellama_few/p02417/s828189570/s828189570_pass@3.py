import sys
table = "abcdefghijklmnopqrstuvwxyz"
sentence1 = sentence.lower()
print(str(sentence1.count(i)))