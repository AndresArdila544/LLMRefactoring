n = int(input())
while n != 0:
    count = 1
    x = int(input())
    if x != 0:
        print('Case {0}: {1}'.format(count, x))
        count += 1
    else:
        break