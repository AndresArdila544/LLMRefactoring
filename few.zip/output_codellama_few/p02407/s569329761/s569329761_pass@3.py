n = input()
an = input().split()
out_c1 = ' '.join(reversed(an))
print(out_c1[1:])