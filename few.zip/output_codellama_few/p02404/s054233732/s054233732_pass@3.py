while N := list(map(int, input().split())))[0] + N[1]: print("#", end="") 
if i in (0, N[0] - 1): for j in range(1, N[1] - 1): print("#", end="") 
print("#\n", end="")