import sys
x = sys.stdin.readline().split()
m = sorted(map(int, x))
a, b, c = m[0], m[1], m[2]
print a, b, c