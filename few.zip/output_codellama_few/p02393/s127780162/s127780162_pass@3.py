m = map(int, raw_input().split())
print m[0], m[1], m[2]