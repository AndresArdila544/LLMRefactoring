def get_fractions(a, b):
    return a / b, a % b, float(a) / b