def calc(a, b):
    print a/b
    print a%b
    print float(a)/b