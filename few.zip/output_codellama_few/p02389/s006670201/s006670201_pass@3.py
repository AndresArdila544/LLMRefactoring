import sys

tate, yoko = map(int, input().split())

print(tate * yoko, 2 * tate + 2 * yoko)