Here is a refactored version of the original code:

tate, yoko = map(int, input().split())
print(f"{tate * yoko} {2 * tate + 2 * yoko}")