a, b = map(int, input().split())
if 1 <= a and b <= 100:
    print(a * b, 2 * (a + b))