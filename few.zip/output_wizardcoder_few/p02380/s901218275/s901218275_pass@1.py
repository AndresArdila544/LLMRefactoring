S = lambda a, b, C: (1/2) * a * b * math.sin(math.radians(C)) 
c = lambda a,b,C: math.sqrt(a**2 + b**2 - 2*a*b*math.cos(math.radians(C))
L = lambda a,b,c: a+b+c
h = lambda a,b,C: b * math.sin(math.radians(C)

print(format(S(int(input()), int(input()), float(input()))) 
print(format(L(int(input()), int(input()), c(int(input(), int(input()))), 8))
print(format(h(int(input()), int(input(), float(input())), 8)