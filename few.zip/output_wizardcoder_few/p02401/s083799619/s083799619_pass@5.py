```python
while True:
    a = input()
    if '?' in a:break
    print(int(''.join(a.split()))
```