n = int(input())
while n != 0:
    for _ in range(n):
        print("#" * (W + 1)
    print("\n")
    n = int(input())
""" Refactored version of the program that works as intended, reduces lines and complexity while preserving functionality. """