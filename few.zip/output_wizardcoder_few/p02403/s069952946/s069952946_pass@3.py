n,m = map(int,input().split())
for i in range(1,H+1):
  for j in range(1,W+1):
    print("#", end="")
  print()