```python
h, w = map(int, input().split())
for i in range(h):
    print('#' * w)
```