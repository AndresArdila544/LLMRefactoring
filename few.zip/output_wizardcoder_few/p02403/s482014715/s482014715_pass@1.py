n, w = map(int, input().split())
while n > 0:
    for i in range(w):
        print("#", end="")
    if n > 1:
        print()
    else:
        print()