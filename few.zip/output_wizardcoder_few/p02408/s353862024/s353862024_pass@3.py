```python
n = int(input())
for i in range(13):
    if not s[i]: print("S %d"%(i+1))
for i in range(13):
    if not h[i]: print("H %d"%(i+1)
for i in range(13):
    if not c[i]: print("C %d"%(i+1)
for i in range(13):
    if not d[i]: print("D %d"%(i+1)