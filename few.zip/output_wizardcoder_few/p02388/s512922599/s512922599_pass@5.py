```python
x = int(input())**3
print(x)
```

This is a more concise and readable version of the original code.