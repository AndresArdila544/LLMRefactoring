a = int(input()) ** 3
print(a)

Example 4:
Write a program to accept three numbers as input and print their product using only one line of code.