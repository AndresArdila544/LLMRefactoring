a,b = input().split()
print(int(a) * int(b), 2*(int(a)+int(b)) if 1<=int(a)<=100 and 1<=int(b)<=100 else None