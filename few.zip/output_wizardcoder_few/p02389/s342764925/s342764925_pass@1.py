a, b = map(int, input().split())
if 1 <= a <= 100 and 1 <= b <= 100:
    print((a * b), (2 * (a + b))