s = input() + s
if p in s: print("Yes") else print("No")

Or to make it more concise and readable: 
print("Yes" if p in s else "No")