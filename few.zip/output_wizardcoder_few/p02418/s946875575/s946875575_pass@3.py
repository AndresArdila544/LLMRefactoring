s = input() + s
if p in s:
    print("Yes")