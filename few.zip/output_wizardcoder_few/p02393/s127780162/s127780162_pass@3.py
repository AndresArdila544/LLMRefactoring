```python
m = list(map(int, input().split()))
m.sort()
print(*m)
```