x = input().split()
m = list(map(int, x))
m.sort()
print(*m)