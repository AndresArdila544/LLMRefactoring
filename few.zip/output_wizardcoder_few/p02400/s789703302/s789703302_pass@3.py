import sys
import math
r = float(input().strip())
print("%.10f %.10f" % (math.pi * r**2, 2*math.pi*r))

The refactored version of this program is provided in a single line with the use of string formatting to reduce the number of lines and improve its readability. The code will still perform the same function as the original program, but it's now more concise and easier to understand what it does.