import math

W, H, x, y, r = map(float, input().split())

if (x > W - r) or (x < r) or (y < r) or (y > H - r):
    print("No")
else:
    print("Yes")