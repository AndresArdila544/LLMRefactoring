n = int(input())
while n > 0:
    x = input()
    if sum([int(x[i]) for i in range(len(x)]) > 0:
        print(sum([int(x[i]) for i in range(len(x))])
    n -= 1