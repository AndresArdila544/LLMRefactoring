refactored_code = """
import sys
nstr = list(map(int, input().split()))
print("{0} {1} {2}".format(min(nstr), max(nstr), sum(nstr)))
"""

print(refactored_code)