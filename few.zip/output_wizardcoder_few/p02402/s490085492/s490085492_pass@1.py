```python
import sys
n = int(input())
print(*map(int, input().split()), sep=' ')
```