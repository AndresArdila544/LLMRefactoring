a, b, c = map(int, input().split())
print((b - a + 1) // c)