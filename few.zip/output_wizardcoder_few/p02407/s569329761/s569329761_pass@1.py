n = input()
n = int(n)
an = input().split()
out_c1 = ' '.join([str(x) for x in an][::-1]
print(out_c1[1:])