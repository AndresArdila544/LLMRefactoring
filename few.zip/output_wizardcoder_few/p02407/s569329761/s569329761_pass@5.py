n = input()
an = input().split()
print(' '.join(reversed(an))