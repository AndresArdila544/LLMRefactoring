z = int(input())
a = list(map(int, input().split()))
a.reverse()
print(" ".join(map(str, a))