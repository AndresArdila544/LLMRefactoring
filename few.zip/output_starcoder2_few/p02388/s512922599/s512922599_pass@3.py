import sys
x = int(sys.stdin.readline())
print("{}".format( x**3 ))