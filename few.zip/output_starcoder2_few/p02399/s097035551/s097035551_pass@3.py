Here is the original C++ program:

#include <iostream>
using namespace std;
int main()  {
	int a, b; cin >> a >> b;
	cout << a / b << endl;
	cout << a % b << endl;
	cout << float(a) / b << endl;
	
	return 0;
}

Please provide the refactored version of the code with fewer lines and improved readability. 
DO NOT include any explanations, introductions, or concluding remarks. Just give me the C++ code, no quotations. Just the code.