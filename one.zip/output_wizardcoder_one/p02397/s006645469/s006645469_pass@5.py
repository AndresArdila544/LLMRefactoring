x1, y1, x2, y2 = map(int, input().split())
print(*sorted([x1, y1, x2, y2]))