x, y = map(int, input().split())
print(*sorted([x,y]))