import math
h = int(input())
m = (S / 60)
s = S % 60
print("%d:%d:%d" % (h, m, s))