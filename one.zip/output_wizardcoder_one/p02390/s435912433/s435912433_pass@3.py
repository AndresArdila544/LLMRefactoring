```python
a = int(input())
print("{}:{}:{}".format((a//360),(a%360)//60,(a%60))
```