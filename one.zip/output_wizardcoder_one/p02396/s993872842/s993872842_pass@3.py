x = input()
while x != '0':
    print(f"Case {counter}: {x}")
    counter += 1
    x = input()
print("Done")