counter = 0
while True:
    x = input()
    if x == '0':
        break
    print("Case {}: {}".format(counter + 1, x)