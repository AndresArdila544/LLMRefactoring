a = int(input())**3
print(a)