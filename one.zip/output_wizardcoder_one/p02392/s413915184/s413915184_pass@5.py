```python
num_list=input().split()
a,b,c = map(int, num_list)
if a<b and b<c: print('Yes')
else: print('No')
```