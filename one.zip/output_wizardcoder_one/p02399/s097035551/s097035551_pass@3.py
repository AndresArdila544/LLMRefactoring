```python
a, b = map(int, input().split())
print(float(a) / b if a % b == 0 else a/b)
```