```python
import math
a, b = map(float, input().split())
print(a / b)
print(a % b) 
print(float(a) / b)
```