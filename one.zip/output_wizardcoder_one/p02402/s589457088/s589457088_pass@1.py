n = int(input())
x = [int(i) for i in input().split()]
print(*[min(x), max(x), sum(x)]