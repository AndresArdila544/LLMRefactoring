n = int(input())
x = list(map(int, input().split()))
m, b, s = min(x), max(x), sum(x)