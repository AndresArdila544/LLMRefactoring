import sys
n = int(input())
print(*sorted([sum(map(int, input().split()), key=lambda x: (x-min(map(int, input().split())))+max(map(int, input().split()))), print(len(set(map(int, input().split()))), end="")