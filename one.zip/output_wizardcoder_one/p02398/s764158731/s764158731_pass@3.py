a, b, c = map(int, input().split())
print((c//2) - ((a+b-1) // 2))