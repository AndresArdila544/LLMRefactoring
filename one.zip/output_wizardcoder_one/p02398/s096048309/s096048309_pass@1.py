a, b = map(int, input().split())
print((b-a+1) - (c%(b-a))