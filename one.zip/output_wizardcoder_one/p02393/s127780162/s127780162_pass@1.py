```python
x = list(map(int, input().split()))
print(*sorted(x)) 
```