n = int(input())
while n > 0:
    x = int(input())
    print((x*(n-1)//2))