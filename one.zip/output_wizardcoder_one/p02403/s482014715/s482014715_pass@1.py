```python
for i in range(int(input().split())):
    print('#'*int(input())