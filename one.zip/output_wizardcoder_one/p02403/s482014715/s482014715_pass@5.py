```python
for _ in range(int(input())):
    h, w = map(int, input().split())
    print("#" * w
```