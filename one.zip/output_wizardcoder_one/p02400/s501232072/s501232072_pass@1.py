import math
r = float(input())
print(round(math.pi * r**2, 6), round(2*math.pi*r, 6))