```python
import math
def get_circle_areas():
    r = float(input())
    print(round(math.pi * math.pow(r, 2), 6))
    print(round(math.pi * 2 * r, 6)
```