import math
print(f"{math.pi * float(input().rstrip())**2} {2*math.pi*float(input().rstrip())}")