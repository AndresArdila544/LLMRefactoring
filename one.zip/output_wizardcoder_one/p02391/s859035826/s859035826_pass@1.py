a = [int(input()) for i in range(2)]
if a[0] < a[1]:
    print('a < b')
elif a[0] > a[1]:
    print('a > b')
else:
    print('a == b')