n = int(input())
an = input().split()
print(" ".join(reversed(an))