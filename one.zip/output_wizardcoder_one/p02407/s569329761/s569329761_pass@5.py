refactored_code = """n=int(input())
an=input()
print(' '.join(reversed(an.split()))"""