a = list(map(int, input().split()))
print(" ".join(str(x) for x in a[::-1])