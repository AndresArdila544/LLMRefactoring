a,b=map(int,input().split())
print("{:d} {:d}".format(a*b,2*(a+b))