```python
tate, yoko = map(int, input().split())
print(f"{tate * yoko} {2*tate + yoko*2}")