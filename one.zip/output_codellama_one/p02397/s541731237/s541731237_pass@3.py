import math
x1, y1, x2, y2 = map(int, input().split())

while True:
    if x1 > y1:
        print(y1, " ", x1)
    else:
        print(n)