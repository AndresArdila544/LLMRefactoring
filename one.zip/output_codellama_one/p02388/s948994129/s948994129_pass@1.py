import sys
a = int(sys.stdin.readline())**3
print(a)