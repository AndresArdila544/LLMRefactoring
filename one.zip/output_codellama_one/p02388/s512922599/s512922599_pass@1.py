x = int( sys.stdin.readline() )
print( "{}".format( x**3 ) )

import sys
x = int(sys.stdin.readline())
print("{}^3".format(x))