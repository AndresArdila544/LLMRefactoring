x = raw_input().split()
m = map(int,x)
m.sort()
print m[0], m[1], m[2]