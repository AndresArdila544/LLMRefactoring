n = input()
an = input().split()
out_c1 = ' '.join(reversed(an))[1:]
print(out_c1)