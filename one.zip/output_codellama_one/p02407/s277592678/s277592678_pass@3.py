z = int(input())
a = list(map(int, input().split()))
print(" ".join(map(str, a)))