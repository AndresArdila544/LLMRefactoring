Here is a refactored version of the code:

z = int(input())
print(" ".join(map(str, sorted(a, reverse=True))))