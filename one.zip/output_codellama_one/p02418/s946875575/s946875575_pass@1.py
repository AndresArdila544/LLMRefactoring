import str(input())
p = str(input())
if p in s:
    print("Yes")
else:
    print("No")