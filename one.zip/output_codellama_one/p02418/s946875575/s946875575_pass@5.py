s = str(input())
p = str(input())
if p in s * 2:
    print("Yes")
else:
    print("No")