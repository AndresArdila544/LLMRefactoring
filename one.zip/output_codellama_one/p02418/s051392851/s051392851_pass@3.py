```
p = input() *2
print('Yes' if p in s else 'No')
```