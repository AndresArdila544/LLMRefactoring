n = int(input())
x = list(map(int, input().split()))
print(*min_max_sum(x))