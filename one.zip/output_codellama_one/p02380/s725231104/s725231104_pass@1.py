import math
a,b,C=map(float,input().split())
print("%f"%((1/2*a*b*math.sin(math.radians(C)))/a*2))