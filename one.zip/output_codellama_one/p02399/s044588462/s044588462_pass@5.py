a,b = map(int,input().split())
print(str(a//b)+' '+str(a%b)+' '+str(a/b))