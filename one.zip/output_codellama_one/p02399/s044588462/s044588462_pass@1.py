a, b = map(int, input().split())
print(f'{d} {r} {f}')