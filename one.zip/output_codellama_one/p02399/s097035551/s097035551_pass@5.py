import math
a, b = map(int, raw_input().split())
d = math.hypot(a, b)
print d