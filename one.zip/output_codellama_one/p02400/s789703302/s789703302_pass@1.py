import sys
import math
r = float(sys.stdin.readline().rstrip())
print(f"{math.pi * r ** 2:.10f} {2 * math.pi * r:.10f}")