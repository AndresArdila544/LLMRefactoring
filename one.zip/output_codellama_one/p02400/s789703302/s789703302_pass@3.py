import sys
import math
r = float(sys.stdin.readline().rstrip())
print("%.10f %.10f"%(math.pi*r**2,2*math.pi*r))