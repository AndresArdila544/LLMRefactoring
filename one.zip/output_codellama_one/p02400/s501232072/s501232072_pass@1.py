def main():
    r = float(input())
    print("{0:.6f}".format(math.pi * math.pow(r, 2)))
    print("{0:.6f}".format(math.pi * 2 * r))