import math
a, b, c = map(int, input().split())
d=math.sqrt((b-a)*(b-a)+c*c)