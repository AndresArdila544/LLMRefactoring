num_list=input().split()
if a<b<c:
    print('Yes')
else :
    print('No')