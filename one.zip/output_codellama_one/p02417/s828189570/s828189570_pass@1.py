import sys
table = "abcdefghijklmnopqrstuvwxyz"
sentence1 = sentence.lower()
for i in table:
print(i + ' : ' + str(sentence1.count(i)))