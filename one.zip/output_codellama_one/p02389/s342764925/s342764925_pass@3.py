a,b=input().split()
if int(a) in range(1,101):
    print((int(a)*int(b)), 2*(int(a)+int(b)))