a, b = input().split()
if 1 <= int(a) <= 100 and 1 <= int(b) <= 100:
    print((int(a) * int(b)), (2 * (int(a) + int(b))))