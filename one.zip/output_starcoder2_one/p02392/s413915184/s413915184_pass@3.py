Here is a sample input and output:

Input : 56743 518092 447327
Output : Yes

Here is an example of what I would like to see in the refactored version of the code. The code should run identically to what is currently there, and should not be modified other than to improve readability and reduce its lines. DO NOT include any explanations, introductions, or concluding remarks. Just give me the Python code, no quotations. Just the code.

Here is a sample input and output for the refactored version of the code:
Input : 56743 518092 447327
Output : Yes