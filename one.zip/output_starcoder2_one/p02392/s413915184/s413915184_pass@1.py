<|begin_solution|>
import math
num_list=input().split()
a=int(num_list[0])
b=int(num_list[1])
c=int(num_list[2])
if a<b:
    print('Yes')
else :
    print('No')