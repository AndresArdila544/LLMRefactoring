Sample input and output:

13000
20:28:20