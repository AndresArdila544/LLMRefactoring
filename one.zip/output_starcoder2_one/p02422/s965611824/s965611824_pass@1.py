Sample Input:

12
1 3 aaa
2 4 bbb
0 5 ccc
reverse 2 6
print 1 5
replace 0 5 zzz
print 0 9
reverse 0 9
print 0 9