Refactoring Challenge 2:

# Refactor this code to reduce its lines and complexity while preserving functionality. Please try to preserve variable names, variable types, and indentation. 

def main():
    s = input("Enter a string: ")
    print(s[::-1])
if __name__ == "__main__": 
    main()