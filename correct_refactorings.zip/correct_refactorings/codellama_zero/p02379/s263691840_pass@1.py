x1,y1,x2,y2=map(float,input().split())
import math
print(f"{math.sqrt((x1-x2)**2+(y1-y2)**2):.08f}")