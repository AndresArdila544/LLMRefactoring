x = input()
while x != '0':
    goukei = sum(list(map(int, x)))
    print(goukei)
    x = input()