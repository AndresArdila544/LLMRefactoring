input()
print(*reversed(input().split()),sep=' ')