n=int(input())
print(*input().split()[::-1])