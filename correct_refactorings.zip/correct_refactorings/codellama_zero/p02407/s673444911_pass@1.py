n = int(input())
print(*reversed(input().strip().split()), sep=' ')