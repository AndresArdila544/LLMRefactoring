a, b = map(int, input().split())
print(f"{a // b} {a % b} {a / b:0.10f}")