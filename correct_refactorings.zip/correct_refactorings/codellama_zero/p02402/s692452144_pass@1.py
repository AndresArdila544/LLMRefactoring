n = input()
ai = map(int, raw_input().split())
print min(ai), max(ai), sum(ai)