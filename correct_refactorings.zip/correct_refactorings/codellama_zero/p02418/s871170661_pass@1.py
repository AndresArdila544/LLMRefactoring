string = input()
pattern = input()
if pattern in string * 2:
    print("Yes")
else:
    print("No")