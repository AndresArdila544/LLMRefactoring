s = input()
sdouble = s*2
p = input()
print('Yes' if sdouble.find(p)!= -1 else 'No')