s = input() * 2
p = input()
print('Yes') if p in s else print('No')