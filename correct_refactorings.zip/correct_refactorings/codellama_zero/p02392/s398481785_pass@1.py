a,b,c = map(int,input().split())
print("Yes" if a<b and b<c else "No")