import math

r = float(input())
rs = r * r * math.pi
r_r = 2 * r * math.pi
print(f"{rs} {r_r}")