import math
r = float(input())
print('{:.6f}'.format(math.pi*r**2),'{:.6f}'.format(2*math.pi*r))