import math
r = float(input())
print(f"{r * r * math.pi:.10f} {2 * r * math.pi:.10f}")