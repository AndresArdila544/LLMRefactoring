from math import pi, sqrt
r = float(input())
s = r ** 2 * pi
l = 2 * r * pi
print("{0:.6f} {1:.6f}".format(s, l))