r=float(input())
print((r**2)*3.141592653589,"{:.6f}".format(2*r*3.141592653589))