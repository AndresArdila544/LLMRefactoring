x = float(input())
y = 3.141592653589
a = x**2 * y
b = (x + x) * y
print("{0:.6f} {1:.6f}".format(a, b))