x = input().split()
if int(x[0]) < int(x[1]):
    print("a < b")
elif int(x[0]) == int(x[1]):
    print("a == b")
else:
    print("a > b")