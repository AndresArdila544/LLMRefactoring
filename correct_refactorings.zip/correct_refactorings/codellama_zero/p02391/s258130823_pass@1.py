s=input().split()
if int(s[0])>int(s[1]):print("a > b")
elif int(s[0])<int(s[1]):print("a < b")
else:print("a == b")