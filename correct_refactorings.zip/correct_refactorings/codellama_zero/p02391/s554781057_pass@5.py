a, b = map(int, input().split())
if a < b: print("{0} < {1}".format('a', 'b'))
elif a > b: print("{0} > {1}".format('a', 'b'))
else: print("{0} == {1}".format('a', 'b'))