for i in range(10000):
    x = int(input())
    if not x:
        break
    
    print('Case {}: {}'.format(i + 1, x))