x=input()
print(x.swapcase())