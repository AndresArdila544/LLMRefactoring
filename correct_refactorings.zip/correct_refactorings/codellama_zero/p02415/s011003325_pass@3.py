buff=input().swapcase()
print(buff)