x = float(input())
y=3.141592653589
a=x*x*y
b=(x+x)*y
print("{0:.6f} {1:.6f}".format(a, b))