x, y = map(lambda x: int(x), input().split(" "))
print((x * y), (2 * x + 2 * y))