import sys

x = int(input())
print(x**3)