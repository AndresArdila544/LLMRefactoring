# Refactored version:
a, b = map(int, input().split())
print(f"{a // b} {a % b} {a / b}")