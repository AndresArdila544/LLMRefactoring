import math
tate,yoko = map(int,input().split())
syuu = 2*tate + yoko*2
print(tate*yoko, syuu)