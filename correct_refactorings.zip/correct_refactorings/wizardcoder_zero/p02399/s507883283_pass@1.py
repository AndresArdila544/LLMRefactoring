a, b = map(int, input().split())
print(f"{a // b} {a % b:02d} {a / b:.8f}")