a, b = map(int, input().split())
print("{:d} {:d} {:0.10f}".format(a//b, a%b, a/b))