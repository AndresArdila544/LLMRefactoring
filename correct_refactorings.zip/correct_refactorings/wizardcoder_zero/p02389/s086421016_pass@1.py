l = list(map(int, input().split())) # Convert input string to a list of integers
print(l[0]*l[1], 2*(sum(l))) # Print first element multiplied by second element and doubled sum of the list.