s = input().split()
print(int(s[0])*int(s[1]), (int(s[0]) + int(s[1]))*2)