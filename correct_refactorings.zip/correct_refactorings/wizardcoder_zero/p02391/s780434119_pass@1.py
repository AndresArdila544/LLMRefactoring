a, b = map(int, input().split())
print("a < b" if a<b else "a == b" if a==b else "a > b")