s = input() * 2
p = input()
print('Yes') if s.find(p) != -1 else print('No')