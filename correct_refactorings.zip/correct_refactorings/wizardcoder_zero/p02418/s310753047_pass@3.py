s = input()
p = input()
print('Yes' if p in s*2 else 'No')