x=input().swapcase()
print(x)