n = int(input())
A = list(input().split())[::-1]
print(" ".join(A))