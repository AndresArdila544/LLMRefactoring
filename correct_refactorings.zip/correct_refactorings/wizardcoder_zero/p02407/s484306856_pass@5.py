n = int(input())
a = input().split()
print(*reversed(a))