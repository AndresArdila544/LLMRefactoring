n = int(input())
x = list(map(int, input().split()))
print(*[min(x), max(x), sum(x)], sep='\n')