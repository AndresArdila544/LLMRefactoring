n = int(input())
ai = list(map(int, input().split()))
print(min(ai), max(ai), sum(ai))