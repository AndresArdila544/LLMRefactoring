n = int(input())
table = list(map(int, input().split()))
print(min(table), max(table), sum(table))