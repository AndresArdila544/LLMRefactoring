counter = 1
while True:
    x = input()
    if x == '0': break
    print(f"Case {counter}: {x}")
    counter += 1