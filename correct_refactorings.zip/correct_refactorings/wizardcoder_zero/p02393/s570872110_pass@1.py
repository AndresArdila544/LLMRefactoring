num_sorted = sorted(map(int, input().split()))
print(*num_sorted[:3])