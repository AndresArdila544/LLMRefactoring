n = list(map(int, input().split()))
print(*sorted(n))