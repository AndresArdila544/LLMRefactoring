num = list(map(int, input().split()))
print(*sorted(num), sep=" ")