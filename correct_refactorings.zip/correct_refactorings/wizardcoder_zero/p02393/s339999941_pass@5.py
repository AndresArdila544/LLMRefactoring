a, b, c = map(int, input().split())
sorted_abc = sorted([a, b, c])
print(*sorted_abc)