r = float(input())
print('{0:f} {1:f}'.format(r*r*3.141592653589793, 2 * r * 3.141592653589793))