a = float(input())
print("{0:.6f} {1:.6f}".format(a * a * 3.141592653589, (a + a) * 3.141592653589))