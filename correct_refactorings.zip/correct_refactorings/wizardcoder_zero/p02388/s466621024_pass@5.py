x = int(input())
print(pow(x,3))