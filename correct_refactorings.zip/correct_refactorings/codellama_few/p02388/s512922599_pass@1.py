import sys
x = int(sys.stdin.readline())
print(f"{x**3}")