import math
r = float(input())
print(round(math.pi * r ** 2, 6), round(math.pi * 2 * r, 6))