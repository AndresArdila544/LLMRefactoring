n = int(input())
an = input().split()[::-1]
print(' '.join(an))