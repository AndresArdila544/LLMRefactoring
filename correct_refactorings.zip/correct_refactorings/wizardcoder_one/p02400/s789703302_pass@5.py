import math
r = float(input().strip())
print("{:.10f} {:.10f}".format(math.pi*r**2, 2*math.pi*r))