x = int(input()) ** 3
print(x)