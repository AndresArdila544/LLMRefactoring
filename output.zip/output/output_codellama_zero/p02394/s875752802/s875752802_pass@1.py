W, H, x, y, r = map(int, input().split())
if (0 <= x) and (x + r <= W) and (0 <= y) and (y + r <= H):
    print("Yes")