import math

a,b,c=map(int,input().split())
if c<=90:
    C=((A-X)**2+H*H)**0.5
    print(C+a+b)
    print(h)
else:
    X=(B*B-H*H)**0.5
    C=((A-X)**2+H*H)**0.5
    print(C+a+b)
    print(h)