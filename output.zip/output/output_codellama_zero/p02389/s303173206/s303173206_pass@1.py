S=input()
s=S.split()
a = int(s[0])
b = int(s[1])
m = a*b
n = 2*a+2*b
print(str(m)+" "+str(n))