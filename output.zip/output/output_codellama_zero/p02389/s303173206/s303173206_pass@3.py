S = input()
a, b = map(int, S.split())
print(f'{a * b} {2 * a + 2 * b}')