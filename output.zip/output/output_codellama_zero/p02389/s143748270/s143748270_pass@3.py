l=input().split()
print(w*h,2*w+2*h)