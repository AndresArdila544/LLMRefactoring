l=input().split()
print(int(l[0])*int(l[1]),2*int(l[0])+2*int(l[1]))