def main():
    l = input().split()
    a, b = int(l[0]), int(l[1])
    print(a*b, 2*(a+b))