Here is a refactored version of the code that reduces its lines and improves its readability:

def main():
    a, b = map(int, input().split())
    print(a*b, 2*(a+b))


if __name__ == "__main__":
    main()