x, y = map(int, input().split())
print(f"{s=}, {p=}")