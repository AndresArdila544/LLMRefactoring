x,y = map(int,input().split())
print("{} {}".format(x*y,2*x+2*y))