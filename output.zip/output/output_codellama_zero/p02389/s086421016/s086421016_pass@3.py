l = [int(x) for x in input().split()]
print(l[0]*l[1], 2*(l[0]+l[1]))