tate, yoko = map(int, input().split())
print((tate * yoko), (2*tate + yoko*2))