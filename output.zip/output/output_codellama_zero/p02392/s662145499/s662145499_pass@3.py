Here's the refactored version:
print("Yes" if a < b < c else "No")