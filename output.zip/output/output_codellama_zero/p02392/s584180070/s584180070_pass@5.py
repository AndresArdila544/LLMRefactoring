a,b,c = input().split()
print("Yes" if a<b<c else "No")