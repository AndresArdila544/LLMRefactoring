n = input().split()
print('Yes' if sorted(map(int, n)) == n else 'No')