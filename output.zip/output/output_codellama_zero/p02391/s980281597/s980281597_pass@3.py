```
# coding: utf-8!
a, b = input().split()
print("a > b" if a > b else "a < b" if a < b else "a == b")
```