if __name__ == "__main__":
    a, b = map(int, input().split())
    print("a ==", a, "b", sep='') if a == b else \