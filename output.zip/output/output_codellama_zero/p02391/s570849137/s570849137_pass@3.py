x = input().split()
if a := int(x[0]) < b := int(x[1]):
    print("a < b ")
elif a == b:
    print("a == b")
else:
    print("a > b")