s=input().rstrip().split(' ')
print(f'{"a > b" if a>b else "a == b" if a==b else "a < b"}')