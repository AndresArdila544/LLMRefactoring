import math

num = input()
num2 = math.pow(num,3)
print(num2)