Here is a possible refactoring of your original code:

import math
num = input()
print(math.pow(num,3))