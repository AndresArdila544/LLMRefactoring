import sys
print(sys.stdin.readline().strip())**3)