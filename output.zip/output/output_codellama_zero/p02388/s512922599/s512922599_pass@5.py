import sys
print("{}".format(int(sys.stdin.readline()) **3))