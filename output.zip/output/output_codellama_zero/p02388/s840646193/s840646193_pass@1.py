N = int(input())
print(str(N)**3)