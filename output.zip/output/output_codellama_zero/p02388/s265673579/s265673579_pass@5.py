# -*- coding: utf-8 -*-

def main():
    print(input() ** 3)

if __name__ == "__main__":
    main()