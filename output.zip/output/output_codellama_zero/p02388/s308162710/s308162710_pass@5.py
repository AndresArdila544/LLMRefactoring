x = int(raw_input())
print x**3