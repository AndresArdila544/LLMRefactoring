Here is a refactored version of the original program:

x = int(input())
print(x**3)