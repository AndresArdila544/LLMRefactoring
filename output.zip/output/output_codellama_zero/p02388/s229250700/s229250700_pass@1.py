Here's a refactored version of the code:

#!/usr/bin/env python

x = int(input())
print x ** 3