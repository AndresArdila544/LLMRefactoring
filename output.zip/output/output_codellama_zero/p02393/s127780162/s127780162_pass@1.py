```
m = list(map(int, raw_input().split()))
m.sort()
print (m[0], m[1], m[2])
```