x = raw_input().split()
m = map(int, x)
print a, b, c