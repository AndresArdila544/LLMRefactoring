# Refactoring
print(*sorted(map(int, input().split())), sep=',')