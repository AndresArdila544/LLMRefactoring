n = sorted(map(int, input().split()))
for n in n:
    print(n, end=' ')