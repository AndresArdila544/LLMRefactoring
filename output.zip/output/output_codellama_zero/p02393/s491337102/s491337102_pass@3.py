Here is the refactored code:

n = sorted([int(num) for num in input().split()])
for num in n:
    print(num, end=' ')
print()