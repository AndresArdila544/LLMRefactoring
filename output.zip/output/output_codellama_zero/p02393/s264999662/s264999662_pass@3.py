a, b, c = map(int, input().split())
print(*sorted([a, b, c]))