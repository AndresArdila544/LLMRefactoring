Here is the refactored version of the code:

a = sorted(map(int, input().split()))
print(*a)