a = sorted(list(map(int, input().split())))
print(*a)