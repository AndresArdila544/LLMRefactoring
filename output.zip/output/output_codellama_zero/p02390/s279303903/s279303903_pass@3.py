Here is the refactored version:

print(str(s//3600) + ":" + str((s%3600)//60) + ":" + str(s%60))