S = input()
print(str((S - (h*60*60) - (m*60)))[2:])