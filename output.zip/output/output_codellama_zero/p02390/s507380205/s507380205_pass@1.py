sec = int(input())
print("{}:{}:{}".format(*divmod(sec, 3600)))