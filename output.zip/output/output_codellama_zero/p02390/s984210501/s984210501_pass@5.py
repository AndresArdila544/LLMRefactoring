Here is the refactored version of your original Python program:

print(*divmod(int(input()),3600),sep=':')