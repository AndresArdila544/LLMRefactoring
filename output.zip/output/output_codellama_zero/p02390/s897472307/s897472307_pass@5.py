a = input()
print(f"{int(a)//3600}:{(int(a)-int(a)//3600)*60} %60")