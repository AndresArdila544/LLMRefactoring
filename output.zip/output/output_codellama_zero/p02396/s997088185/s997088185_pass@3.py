i = 0
while True:
    x = input()
    i += 1
    if x == "0":
        break
    print(f'Case {i}: {x}')