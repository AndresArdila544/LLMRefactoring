import sys
for x in iter(sys.stdin.readline, '0'):
    print "Case %s: %s" % (i,x)