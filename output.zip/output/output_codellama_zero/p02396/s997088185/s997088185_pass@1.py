i = 0
 while True:
        x = raw_input()
        if x == "0":
                break
        print 'Case %d: %s' %(i,x)