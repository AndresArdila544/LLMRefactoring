def get_input():
    x = input()
    if x == '0':
        break
    else:
        print("Case {}: {}".format(counter, x))
        counter += 1

This is a simplified version of the program that reduces its complexity and line count.