Here is the refactored version of the program:

while True:
    x = input()
    if x == '0': break
    print(f"Case {counter}: {x}")