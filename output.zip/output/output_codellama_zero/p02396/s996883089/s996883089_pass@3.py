count = 1
while True:
    x = int(input())
    if x == 0: break
    print("Case {} : {}".format(count,x))
    count += 1