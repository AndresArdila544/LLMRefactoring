import math
x1, y1 = map(float, input().split())
print(math.dist(x2, y2))