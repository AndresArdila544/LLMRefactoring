import math
print(math.sqrt((x2-x1)**2+(y2-y1)**2))