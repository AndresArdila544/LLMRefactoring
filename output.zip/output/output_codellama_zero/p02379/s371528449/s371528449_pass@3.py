import math
input_list = input().split( )
x1 = float(x1)
y1 = float(y2)
x2 = float(x2)
y2 = float(y2)
print(math.sqrt((x1-x2)**2 + (y1-y2)**2))