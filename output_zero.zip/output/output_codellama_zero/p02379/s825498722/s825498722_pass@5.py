import math
print(math.dist(x1, y1, x2, y2))