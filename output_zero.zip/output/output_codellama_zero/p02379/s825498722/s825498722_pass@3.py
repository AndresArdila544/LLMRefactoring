import math
x1, y1, x2, y2 = [float(_) for _ in input().split()]
print(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)))