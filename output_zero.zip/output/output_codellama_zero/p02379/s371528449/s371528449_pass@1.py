import math

x1, y1, x2, y2 = input().split()
print(math.sqrt((float(x1) - float(x2))**2 + (float(y1) - float(y2))**2))