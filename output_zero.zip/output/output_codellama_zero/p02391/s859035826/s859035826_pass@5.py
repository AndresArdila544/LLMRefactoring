a = [int(e) for e in input().split()]
print('a ' + ('<' if a[0] < a[1] else ''))