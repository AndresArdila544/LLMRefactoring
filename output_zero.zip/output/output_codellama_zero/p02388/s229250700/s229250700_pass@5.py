Here is a refactored version of the code:

#!/usr/bin/env python

# coding: utf-8


print (raw_input()) ** 3