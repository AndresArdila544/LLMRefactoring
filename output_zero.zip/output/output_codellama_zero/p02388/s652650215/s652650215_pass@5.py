import math
print(pow(input(),3))