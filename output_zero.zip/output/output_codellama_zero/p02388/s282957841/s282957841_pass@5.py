import math;
in_put = input("");
print(int(math.pow(float(in_put),3)))