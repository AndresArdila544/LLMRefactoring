import math
in_put = input("")
print(math.pow(float(in_put),3))