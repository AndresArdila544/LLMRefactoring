def cubic(a):
    print(pow(a,3))