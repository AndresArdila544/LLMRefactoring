Here is a more concise and readable version of the code:

print(str(int(input())**3))