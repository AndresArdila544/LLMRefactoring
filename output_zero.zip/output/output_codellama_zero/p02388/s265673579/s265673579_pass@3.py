```
# -*- coding: utf-8 -*-

def main():
    x = int(input())
    print(f"{x ** 3}")


if __name__ == "__main__":
    main()
```