Here is a more efficient way to achieve the same result:

print(int(input("")) ** 3)