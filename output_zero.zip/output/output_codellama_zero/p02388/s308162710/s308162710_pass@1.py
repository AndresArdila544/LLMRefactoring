Here is the refactored version of the code:

print(f"{x**3}")