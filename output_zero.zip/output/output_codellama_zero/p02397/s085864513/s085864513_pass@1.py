def print_sorted(a):
    a = list(map(int, raw_input().split()))
    if a == [0, 0]: break
    for x in a:
        print x,
    print

while True:
   print_sorted()