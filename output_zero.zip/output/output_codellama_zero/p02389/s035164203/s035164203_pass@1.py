x, y = map(int, input().split())
print("%d %d"%(x*y,2*(x+y)))