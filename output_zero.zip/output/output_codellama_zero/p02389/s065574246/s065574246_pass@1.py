Here is the refactored version of the code:

x, y = map(int, input().split(" "))
print(f"{x * y} {2 * x + 2 * y}")