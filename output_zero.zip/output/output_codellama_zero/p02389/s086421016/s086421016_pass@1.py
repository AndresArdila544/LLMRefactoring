l = list(map(int, input().split()))
print((l[0]*l[1]), 2*(l[0]+l[1]))