Here is a refactored version of your original program:

n = int(input())
print((n[0]*n[1],2*(n[0]+n[1]))