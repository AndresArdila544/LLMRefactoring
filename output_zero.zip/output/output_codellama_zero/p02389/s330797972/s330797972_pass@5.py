num = input()
l = num.split(" ")
a,b = int(l[0]),int(l[1])
print(a*b," ",a*2+b*2)