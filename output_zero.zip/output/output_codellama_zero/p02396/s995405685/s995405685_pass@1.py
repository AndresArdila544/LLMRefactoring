import sys
print('\n'.join(str('Case '+ str(i+1)+':'+' '+ str(a[i]))for i in range(len(a)-1)))