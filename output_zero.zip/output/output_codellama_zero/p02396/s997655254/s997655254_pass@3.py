i = 0
while True:
    x = int(input())
    if not x:
        break
    print(f"Case {++i}: {x}")