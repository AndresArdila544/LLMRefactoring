h, m, s = map(int, input().split(':'))
print('%d:%d:%d' % (h,m,s))