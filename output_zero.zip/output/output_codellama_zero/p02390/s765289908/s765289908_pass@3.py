Here is a cleaner, more concise, and improved-readability version of the original code:

print(f"{s // 3600}:{s % 3600 // 60}:{s % 60}")