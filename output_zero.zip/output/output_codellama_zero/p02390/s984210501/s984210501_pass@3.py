a = int(input())
print(*divmod(a, 3600), sep=":")