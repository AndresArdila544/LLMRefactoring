```a = int(input())
b = int(input())
c = int(input())
if (a < b) & (b < c):
    print("Yes")
else:
    print("No")`