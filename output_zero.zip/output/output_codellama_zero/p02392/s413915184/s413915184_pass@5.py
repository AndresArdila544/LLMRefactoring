num_list=input().split()
print("Yes" if a<b<c else "No")