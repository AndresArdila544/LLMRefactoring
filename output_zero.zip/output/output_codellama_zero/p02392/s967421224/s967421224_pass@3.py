n = input().split()
a, b , c = map(int, n)
print('Yes' if a < b < c else 'No')