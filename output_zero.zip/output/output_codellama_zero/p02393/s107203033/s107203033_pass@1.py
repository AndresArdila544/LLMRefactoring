Here is a refactoring of the original Python program:

num = sorted(input().split())
print(*num, sep=" ")