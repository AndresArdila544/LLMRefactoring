Here is the refactored version of the program:

num = input().split()
print(*sorted(num), sep=' ')