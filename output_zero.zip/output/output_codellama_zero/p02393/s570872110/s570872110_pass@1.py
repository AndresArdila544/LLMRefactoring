num_sorted = sorted(map(int, input().split()))
print("{} {} {}".format(*num_sorted))