Here is the refactored Python program:
n = sorted(list(map(int, input().split())))
for n in n:
    print(n, end=' ')
print()