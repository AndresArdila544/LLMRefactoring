x = raw_input().split()
m = map(int, x)
print sorted(m)[0], sorted(m)[1], sorted(m)[2]